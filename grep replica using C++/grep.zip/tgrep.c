//header files 
#include <stdio.h>
#include <string.h>
#include <regex.h>
#include <stdbool.h>
#include <dirent.h> 
#include <stdlib.h>
#include <pthread.h>


//global varibles
char* print = NULL;

bool search_result = false;
char* prompt = NULL;
char** thread_result;
//.................
struct thread_value{
    long file_seek;
    char* address;
    int start_line ; 
    int thread_num ;
    int match;
};
struct options{
        bool reverse; // -v
        bool line_num; // -n
        bool count; // -c 
        bool is_dir; //directory probing
        int search_mode; // 0 for regex 1 for exact search and 2 for simple search
        int line_number;
        int total_line;
        int thread_num;
};
 //                      reverse  line num ,count ,want directory probing, search mode , line number 
struct options option = {false , true , true,false ,2,0,0,1};
//..................................................
void version(){
    printf("Mini Grep Version 3.2, Beta __ Happy using :)\n");
}
//.......................................................
char* regexToString(int length , char* in){//depricated :(
    char* out = (char) malloc(length*sizeof(char));
    out = in;
    return out;
}
//.......................................................
char* tostring(int input){
    char* str = malloc(15*sizeof(char));
    sprintf(str, "%d", input);
    return str;
}
//.......................................................
char* stringCat(char* s1, char* s2){
    if(s1 == NULL){
        char* ret  = calloc(strlen(s2)+1,sizeof(char));
        ret[strlen(s2)] = '\0';
        return ret;
    }
    int one = strlen(s1);
    int two = strlen(s2);
    char* ret  = calloc(one+two+1,sizeof(char));
    for(int i = 0 ; i <one ; i++){
        ret[i] = s1[i];
    }
    for(int i = 0 ; i < two ; i++){
        ret[i+one] = s2[i];
    }
    //free(s1);
    //free(s2);
    ret[one+two] = '\0';
    return ret;
}
void concatenateStrings(char** dest, const char* src) {
    // Calculate the length of the concatenated string
    size_t destLen = *dest ? strlen(*dest) : 0;
    size_t srcLen = strlen(src);
    size_t totalLen = destLen + srcLen + 1; // +1 for the null terminator

    // Reallocate memory for the destination string
    *dest = realloc(*dest, totalLen);
    if (*dest == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        return;
    }

    // Concatenate the source string to the destination string
    strcat(*dest, src);
}
//...................................................
int result_output(char* input , char* word ,int thread_number,int line_number){
    char *token = strtok(input, " ");
    int count = 0;
    int word_len = strlen(word);
    int match = 0;

    if(option.line_num){
        concatenateStrings(&thread_result[thread_number],tostring(line_number));
        concatenateStrings(&thread_result[thread_number],"_ ");
    }
    while (token != NULL) {

        if(option.search_mode == 1){
        
            if(strlen(token) == word_len && strcmp(token,word)==0){
                concatenateStrings(&thread_result[thread_number],"\033[31m");
                concatenateStrings(&thread_result[thread_number],token);
                concatenateStrings(&thread_result[thread_number],"\033[0m ");
                token = strtok(NULL, " ");
                match+=1;
            }
            else{
                concatenateStrings(&thread_result[thread_number],token);
                concatenateStrings(&thread_result[thread_number]," ");
                token = strtok(NULL, " ");
            }
        }
        else{
            if(strstr(token , word)!= NULL){
                concatenateStrings(&thread_result[thread_number],"\033[31m");
                concatenateStrings(&thread_result[thread_number],token);
                concatenateStrings(&thread_result[thread_number],"\033[0m ");
                
                token = strtok(NULL, " ");
                match+=1;
            }
            else{
                concatenateStrings(&thread_result[thread_number],token);
                concatenateStrings(&thread_result[thread_number]," ");                
                token = strtok(NULL, " ");
            }
        }
        count++;
    }
    // if(count_match > 0){
    //     printf(" %d matches found",match);  num of matches in single line 
    // }
    concatenateStrings(&thread_result[thread_number],"\n");
    return match;
}
//...................................................
int exact_simple_search(char* input , char* word ,int thread_number,int line_number){
    char* p = input;
    int word_len = strlen(word);
    int match = 0;


    while(*p) {
        if(strncmp(p, word, word_len) == 0 && (p[word_len] == ' ' || p[word_len] == '\0')) {
//          printf("%s is in %s.\n", word, string);
            match+=1;
            break;
     }
        p++;   
        
     }
    if(option.reverse){
        if(*p == '\0'){
            if(option.line_num){
                concatenateStrings(&thread_result[thread_number],tostring(line_number));
                concatenateStrings(&thread_result[thread_number]," ");
            }
            concatenateStrings(&thread_result[thread_number],input);
            return -1;
        }
        else{
            //printf("all lines contain the keyword %s\n",word);
            return 0;
        }
    }
    else{
        if(*p == '\0'){
            //printf("there is no line that has the keyword %s \n",word);
            return 0;
        }
        else{
            return result_output(input , word ,thread_number,line_number);
        }
    }
}
//....................................................
int re_output(char* input , char* pattern,int thread_number,int line_number){
    //concatenateStrings(&thread_result[thread_number],tostring(line_number));
    regex_t regex;
    regmatch_t match;
    char*str = malloc(sizeof(char));
    int count = 0;
    int stat;
    //...............................

    if(line_number){
        concatenateStrings(&thread_result[thread_number],tostring(line_number));
        concatenateStrings(&thread_result[thread_number],"_ ");
    }


    stat = regcomp(&regex, pattern, REG_EXTENDED);

    char *point = input;

    while (regexec(&regex, point, 1, &match, 0) == 0) {
        // Print the matched word
        concatenateStrings(&thread_result[thread_number],"-> \033[31m");
        str = realloc(str,(int)(match.rm_eo - match.rm_so));
        sprintf(str, "%.*s", (int)(match.rm_eo - match.rm_so), point + match.rm_so);
        concatenateStrings(&thread_result[thread_number],str);
        concatenateStrings(&thread_result[thread_number]," \033[0m ");
        count +=1;
        point += match.rm_eo;
    }

    regfree(&regex);
    free(str);
    //if(count_match > 0){
        //printf(" %d matches found\n",count); mathch count for each line 
        //return 1;
    //}
    concatenateStrings(&thread_result[thread_number],"\n");
    return count;
}
//....................................................
int simple_search(char* input , char* word ,int thread_number,int line_number){
    //concatenateStrings(&thread_result[thread_number],tostring(1));
    //printf("%d_%s",line_number,input);
    //printf("%s\n",print);
    char* result = strstr(input,word);
    
    if(result == NULL){
        if(option.reverse){
            if(option.line_num){
                concatenateStrings(&thread_result[thread_number],tostring(line_number));
                concatenateStrings(&thread_result[thread_number],"_ ");
            }
            concatenateStrings(&thread_result[thread_number],input);
            return -1;
        }
        else{
            //printf("No match for keyword %s\n",word);
            return 0;
        }
    }
    else{
        if(option.reverse){
            //printf("all lines include the keyword %s\n",word);
            return 0;
        }
        else{
            return result_output(input , word ,thread_number,line_number);
        }
    }
}
//...................................................

//.....................................................
int regex_search(char *string, char *pattern,int thread_number,int line_number){
    regex_t regex;
    int stat;

    stat = regcomp(&regex, pattern, REG_EXTENDED);

    if (stat) {
        printf("error compiling the regular expression! \n");
        return 0;
    }

    stat = regexec(&regex, string, 0, NULL, 0);

    if(option.reverse){
        if(stat == REG_NOMATCH){
            if(option.line_num){
                concatenateStrings(&thread_result[thread_number],tostring(line_number));
                concatenateStrings(&thread_result[thread_number]," ");
            }
            concatenateStrings(&thread_result[thread_number],string);
            return -1;
        }
        else{
            //printf("all lines have a match");
            return 0;
        }
    }
    else{
        if (!stat) {
            regfree(&regex);
            return re_output(string , pattern,thread_number,line_number);
        } 
        else if (stat == REG_NOMATCH) {
            // printf("No match found ");
            return 0;
        } 
        else {
            char msgbuf[100];
            regerror(stat, &regex, msgbuf, sizeof(msgbuf));
            fprintf(stderr, "Regex match failed: %s\n", msgbuf);
            regfree(&regex);
            return 0;
        }
    }
    

    // Free the compiled regular expression
    regfree(&regex);
    return 1;
}
//....................................................
void* file_handle_thread(struct thread_value * params){
    FILE* fp = fopen(params->address , "r");
    int current_line_number = params->start_line;
    int end_line = ((params->thread_num+1)*option.total_line / option.thread_num)+1;
    size_t input_size = 0;
    ssize_t line = 0; 
    char * String = NULL;

    char* word = prompt;
    
    int match  = 0;
    int temp;
    //...........................................
    if(fp == NULL){
        printf("the following file was not supported: %s \n",params->address);
        return;
    }
    fseek(fp,params->file_seek,0);

    if(option.search_mode == 0){
        while ((line = getline(&String, &input_size, fp)) != -1 && current_line_number <= end_line) {
            temp = regex_search(String, word,params->thread_num,current_line_number);
            if(temp > 0){
                match+=temp;
            }
            current_line_number +=1;
        }  
    }
    else if(option.search_mode == 1){
        while ((line = getline(&String, &input_size, fp)) != -1 && current_line_number <= end_line) {
            option.line_number +=1;
            temp = exact_simple_search(String, word,params->thread_num,current_line_number);
            if(temp > 0){
                match+=temp;
            }
            current_line_number +=1;
        }  
    }
    else{
        while ((line = getline(&String, &input_size, fp)) != -1 && current_line_number <= end_line) {
            option.line_number +=1;
            temp = simple_search(String, word,params->thread_num,current_line_number);
            if(temp > 0){
                match+=temp;
            }
            current_line_number +=1;
        }  
    }

    params->match+=match;

    // if(match > 0 && option.count){
    //     search_result = true;
    //     printf("\033[32m_________________\033[0mthe word \" %s \" had total \033[32m%d\033[0m results in file %s\n\n",word,match,address);
    // }
    fclose(fp);
    free(String);
}
//....................................................
void line_counter(char* file){
    FILE *fp = fopen(file, "r");
    int lineCount = 0;
    size_t input_size = 0;
    ssize_t line = 0; 
    char * String = NULL;

    while (getline(&String, &input_size, fp)!= -1) {
        lineCount++;
    }
    option.total_line = lineCount;
    fclose(fp);
}
//....................................................
void file_thread(char* address){
    line_counter(address);
    if(option.total_line == 0){
        return;
    }
    if(option.thread_num > 1){
        FILE *fp = fopen(address, "r");
        if(fp == NULL){
            return;
        }
        int lineCount = 0;
        size_t input_size = 0;
        ssize_t line = 0; 
        char * String = NULL;
        pthread_t threads[option.thread_num];
        int i = 0;
        int next = 0;
        //............................
        thread_result = malloc(option.thread_num * sizeof(char*));
        for(int u = 0 ; u < option.thread_num; u++){
            thread_result[u] = malloc(sizeof(char));
            strcpy(thread_result[u],"\0");
        }
        //............................
        struct thread_value *  params = malloc(option.thread_num*sizeof(struct thread_value));
        //'..........................
        while (i< option.thread_num) {
            if(lineCount == next){
                params[i].address = address;
                params[i].file_seek = ftell(fp);
                params[i].start_line = lineCount+1;
                params[i].thread_num = i;
                params[i].match = 0;
                pthread_create(&threads[i],NULL,file_handle_thread,&params[i]);
                i++;
                next = (i*(option.total_line / option.thread_num)) +1;
                
                }
            lineCount+=1;
            getline(&String, &input_size, fp);
        }


        for (int j = 0; j < option.thread_num; j++) {
            pthread_join(threads[j], NULL);
        }
        fclose(fp);
        for( i = 0 ; i < option.thread_num ; i++){
            if(strlen(thread_result[i]) > 2){
                 printf("%s",thread_result[i]);
                search_result = true;
            }
        }
        for(i = 0 ; i < option.thread_num ; i++){
            free(thread_result[i]);
        }
        free(thread_result);
        next = 0;
        for(int i = 0 ; i < option.thread_num;i++){
            next+=params[i].match;
        }
        if(next >0){
                printf("\033[32m_________________\033[0mthe word \" %s \" had total \033[32m%d\033[0m results in file %s\n\n",prompt,next,address);
        }

    }
    else{
        printf("only threaded is supported in this version") ;
    }
} 
//.................................................

//.................................................
void dir_manager(char * address){
    DIR *directory_stream;
    struct dirent *dir_store;
    directory_stream = opendir(address);
    //...................................

    if (directory_stream) {
        while ((dir_store = readdir(directory_stream)) != NULL) {
            if (strcmp(dir_store->d_name, ".") == 0 || strcmp(dir_store->d_name, "..") == 0) {
                continue;
            }
            if(dir_store->d_type == 4){
                char *result = malloc(strlen(dir_store->d_name) + strlen(address) + 2);
                strcpy(result,address);
                strcat(result,"/");
                strcat(result,dir_store->d_name);
                //printf("%s",result);
                dir_manager(result);
                free(result);
            }
            else if(dir_store->d_type == 8){
                // printf("%s",address);
                char *result = malloc(strlen(dir_store->d_name) + strlen(address) + 2);
                strcpy(result,address);
                strcat(result,"/");
                strcat(result,dir_store->d_name);
                file_thread(result);
                free(result);
            }
            else{
                continue;
            }   
        
        //printf("%s/%s :  (%hhu)\n", address,dir->d_name,dir->d_type);
        }
        closedir(directory_stream);
    }
    else{
        file_thread(address);
    }
}
//..................................................
void starter(char* address){
    if(option.is_dir){
        dir_manager(address);
    }
    else{
        file_thread(address);
    }
}
int main(int argc , char **argv){
    char* address;
    option.reverse = false;
    option.line_num = false;
    option.count = false;
    option.is_dir = false;
    option.search_mode = 0;
    option.total_line = 0;
    option.thread_num = 2;
    //.........................
    // starter("/home/amir/Desktop/sample.txt");
    // prompt = "hii";
    if(argc < 3){
        // if(strcmp(argv[1],"-version") == 0){
        //     version();
        //     return 0;
        // }
        printf("To few arguments! expected at least a search pattern and an address\n");
        //return 0;
    }
    else if(argc == 3){
        prompt = argv[1];
        address = argv[2];
    }
    else{
        if(argv[1][0] != '-'){
            printf("unacceptible format for search parameters\n");
            return 0;
        }
        else{
            for(int i = 1 ; i < strlen(argv[1]);i++){
                switch(argv[1][i]) {
                    case 'c':
                    option.count = true;
                    break;
                    case 'r':
                    option.reverse = true;
                    break;
                    case 'l':
                    option.line_num = true;
                    break;
                    case 'd':
                    option.is_dir = true;
                    break;
                    case 'v':
                    version();
                    return 0;
                    break;
                    case '0':
                    option.search_mode = 0; // ie regex
                    break;
                    case '1':
                    option.search_mode = 1; // ie exact word
                    break;
                    case '2':
                    option.search_mode = 2; // ie simple search
                    break;
                    case 't':
                    option.thread_num = 2;
                    break;
                    default:
                    printf("invalid option!\n");
                    return 0;
                    }
            }
        }
        prompt = argv[2];
        address = argv[3];
    }
    if(prompt == NULL ){
        printf("An error occured fetching your search request or address !");
        return 0 ;
    }
    else{
        printf("starting with parameters following %s and %s \n",prompt , address);
        starter(address);
    }
    if(!search_result){
        printf("no result !!");
    }  
    return 0;
}
