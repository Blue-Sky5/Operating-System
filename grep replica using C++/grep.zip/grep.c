//header files 
#include <stdio.h>
#include <string.h>
#include <regex.h>
#include <stdbool.h>
#include <dirent.h> 


//global varibles
bool search_result = false;
char* prompt = NULL;

struct options{
        bool reverse; // -v
        bool line_num; // -n
        bool count; // -c 
        bool is_dir; //directory probing
        int search_mode; // 0 for regex 1 for exact search and 2 for simple search
        int line_number;
};
 //                      reverse  line num ,count ,want directory probing, search mode , line number 
struct options option = {false , true , true,false ,2,0};
//..................................................


int result_output(char* input , char* word , int exact,bool line_number,int line_num){
    char *token = strtok(input, " ");
    int count = 0;
    int word_len = strlen(word);
    int match = 0;

    if(line_number){
        printf("%d_ ",line_num);
    }
    while (token != NULL) {

        if(exact == 1){
        
            if(strlen(token) == word_len && strcmp(token,word)==0){
                printf("\033[31m%s\033[0m ",token);
                token = strtok(NULL, " ");
                match+=1;
            }
            else{
                printf("%s ", token);
                token = strtok(NULL, " ");
            }
        }
        else{
            if(strstr(token , word)!= NULL){
                printf("\033[31m%s\033[0m ",token);
                token = strtok(NULL, " ");
                match+=1;
            }
            else{
                printf("%s ", token);
                token = strtok(NULL, " ");
            }
        }
        count++;
    }
    // if(count_match > 0){
    //     printf(" %d matches found",match);  num of matches in single line 
    // }
    printf("\n");
    return match;
}
int re_output(char* input , char* pattern,bool line_number,int line_num){
    regex_t regex;
    regmatch_t match;
    int count = 0;
    int stat;
    //...............................

    if(line_number){
        printf("%d_ ",line_num);
    }


    stat = regcomp(&regex, pattern, REG_EXTENDED);

    char *point = input;

    while (regexec(&regex, point, 1, &match, 0) == 0) {
        // Print the matched word
        printf("--- \033[31m %.*s \033[0m", (int)(match.rm_eo - match.rm_so), point + match.rm_so);
        count +=1;
        point += match.rm_eo;
    }

    regfree(&regex);
    //if(count_match > 0){
        //printf(" %d matches found\n",count); mathch count for each line 
        //return 1;
    //}
    printf("\n");
    return count;
}
int regex_search(char *string, char *pattern , bool reverse,bool line_num,int line_number){
    // flag stands for whether we want matched lines or no mach 


    regex_t regex;
    int stat;

    stat = regcomp(&regex, pattern, REG_EXTENDED);

    if (stat) {
        printf("error compiling the regular expression! \n");
        return 0;
    }

    stat = regexec(&regex, string, 0, NULL, 0);

    if(reverse){
        if(stat == REG_NOMATCH){
            if(line_num){
                printf("%d_ ",line_num);
            }
            printf("%s \n", string);
            return -1;
        }
        else{
            //printf("all lines have a match");
            return 0;
        }
    }
    else{
        if (!stat) {
            regfree(&regex);
            return re_output(string , pattern,line_num,line_number);
        } 
        else if (stat == REG_NOMATCH) {
            // printf("No match found ");
            return 0;
        } 
        else {
            char msgbuf[100];
            regerror(stat, &regex, msgbuf, sizeof(msgbuf));
            fprintf(stderr, "Regex match failed: %s\n", msgbuf);
            regfree(&regex);
            return 0;
        }
    }
    

    // Free the compiled regular expression
    regfree(&regex);
    return 1;
}
int exact_simple_search(char* input , char* word , bool reverse,bool line_num,int line_number){
    //grep -w word address  , flag is for -v , it also supports -c 

    char* p = input;
    int word_len = strlen(word);
    int match = 0;


    while(*p) {
        if(strncmp(p, word, word_len) == 0 && (p[word_len] == ' ' || p[word_len] == '\0')) {
//          printf("%s is in %s.\n", word, string);
            match+=1;
            break;
     }
        p++;   
        
     }
    if(reverse){
        if(*p == '\0'){
            if(line_num){
                printf("%d_ ",line_num);
            }
            printf("%s\n" , input);
            return -1;
        }
        else{
            //printf("all lines contain the keyword %s\n",word);
            return 0;
        }
    }
    else{
        if(*p == '\0'){
            //printf("there is no line that has the keyword %s \n",word);
            return 0;
        }
        else{
            return result_output(input , word , 1,line_num,line_number);
        }
    }
}
int simple_search(char* input , char* word , bool reverse,bool line_num,int line_number){
    //grep word address , flag is for -v, it also supports count or -c
    char* result = strstr(input,word);
    
    if(result == NULL){
        if(reverse){
            if(line_num){
                printf("%d_ ",line_num);
            }
            printf("%s\n",input);
            return -1;
        }
        else{
            //printf("No match for keyword %s\n",word);
            return 0;
        }
    }
    else{
        if(reverse){
            //printf("all lines include the keyword %s\n",word);
            return 0;
        }
        else{
            return result_output(input , word , 0,line_num,line_number);
        }
    }
}
void file_handling(char* address){
    option.line_number = 0;
    FILE *file_pointer;
    size_t input_size = 0;
    ssize_t line = 0; 
    char * String = NULL;

    char* word = prompt;
    
    int match  = 0;
    int temp;
    //...........................................

    file_pointer = fopen(address , "r");

    if(file_pointer == NULL){
        printf("the following file was not supported: %s \n",address);
        return;
    }
    
    if(option.search_mode == 0){
        while ((line = getline(&String, &input_size, file_pointer)) != -1) {
            option.line_number +=1;
            temp = regex_search(String, word,option.reverse,option.line_num,option.line_number);
            if(temp > 0){
                match+=temp;
            }
        }  
    }
    else if(option.search_mode == 1){
        while ((line = getline(&String, &input_size, file_pointer)) != -1) {
            option.line_number +=1;
            temp = exact_simple_search(String, word,option.reverse,option.line_num,option.line_number);
            if(temp > 0){
                match+=temp;
            }
        }  
    }
    else{
        while ((line = getline(&String, &input_size, file_pointer)) != -1) {
            option.line_number +=1;
            temp = simple_search(String, word,option.reverse,option.line_num,option.line_number);
            if(temp > 0){
                match+=temp;
            }
        }  
    }



    // if(match == 0){
    //     printf("Your search had no results !");
    // }

    if(match > 0 && option.count){
        search_result = true;
        printf("\033[32m_________________\033[0mthe word \" %s \" had total \033[32m%d\033[0m results in file %s\n\n",word,match,address);
    }

    free(String);
    fclose(file_pointer);
}
void version(){
    printf("Grep Version 2.0, Beta test*** Happy using :)");
}

//...................................................
void starter(char* address){
    if(option.is_dir){
        dir_manager(address);
    }
    else{
        file_handling(address);
    }
}
void dir_manager(char * address){
    DIR *directory_stream;
    struct dirent *dir_store;
    directory_stream = opendir(address);
    //...................................

    if (directory_stream) {
        while ((dir_store = readdir(directory_stream)) != NULL) {
            if (strcmp(dir_store->d_name, ".") == 0 || strcmp(dir_store->d_name, "..") == 0) {
                continue;
            }
            if(dir_store->d_type == 4){
                char *result = malloc(strlen(dir_store->d_name) + strlen(address) + 2);
                strcpy(result,address);
                strcat(result,"/");
                strcat(result,dir_store->d_name);
                //printf("%s",result);
                dir_manager(result);
                free(result);
            }
            else if(dir_store->d_type == 8){
                // printf("%s",address);
                char *result = malloc(strlen(dir_store->d_name) + strlen(address) + 2);
                strcpy(result,address);
                strcat(result,"/");
                strcat(result,dir_store->d_name);
                file_handling(result);
                free(result);
            }
            else{
                continue;
            }   
        
        //printf("%s/%s :  (%hhu)\n", address,dir->d_name,dir->d_type);
        }
        closedir(directory_stream);
    }
    else{
        file_handling(address);
    }
}

int main(int argc , char **argv){
    char* address;
    option.reverse = false;
    option.line_num = false;
    option.count = false;
    option.is_dir = false;
    option.search_mode = 1;
    //.........................


    if(argc < 3){
        if(strcmp(argv[1],"-version") == 0){
            version();
            return 0;
        }
        printf("To few arguments! expected at least a search pattern and an address\n");
        return 0;
    }
    else if(argc == 3){
        prompt = argv[1];
        address = argv[2];
    }
    else{
        if(argv[1][0] != '-'){
            printf("unacceptible format for search parameters\n");
            return 0;
        }
        else{
            for(int i = 1 ; i < strlen(argv[1]);i++){
                switch(argv[1][i]) {
                    case 'c':
                    option.count = true;
                    break;
                    case 'r':
                    option.reverse = true;
                    break;
                    case 'l':
                    option.line_num = true;
                    break;
                    case 'd':
                    option.is_dir = true;
                    break;
                    case 'v':
                    version();
                    return 0;
                    break;
                    case '0':
                    option.search_mode = 0; // ie regex
                    break;
                    case '1':
                    option.search_mode = 1; // ie exact word
                    break;
                    case '2':
                    option.search_mode = 2; // ie simple search
                    break;
                    default:
                    printf("invalid option!\n");
                    return 0;
                    }
            }
        }
        prompt = argv[2];
        address = argv[3];
    }
    
    if(prompt == NULL ){
        printf("An error occured fetching your search request or address !");
        return 0 ;
    }
    else{
        printf("starting with parameters following %s and %s \n",prompt , address);
        starter(address);   
    }
    if(!search_result){
        printf("no result !!");
    }  
    return 0;
} 


