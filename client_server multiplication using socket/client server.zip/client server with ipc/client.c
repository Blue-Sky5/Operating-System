// client Side:

// important libraries and deffinitions 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>


#define PORT 1191
#define BUFFER_SIZE 1024
#define SERVER_IP "127.0.0.1"

int main(){
    int client_fd;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];
    int x , y ,c = 0;
    int temp = 0;
    char loop;
    int** ans_matrix;
    //answer matrix ..................................
    
    //..................................................
    while(1){
        printf("continue sending multiplication request? y/n");
        scanf(" %c",&loop);
        if(loop == 'n'){
            printf("bye :)\n");
            break;
        }

        printf("For your multiplication please provide three numbers reguarding your input matracies dimentions:\n");
        scanf("%d %d %d",&x , &c, &y);
        //....................
        ans_matrix = (int **)malloc(x * sizeof(int *));
        for(int i = 0 ; i < x ; i++){
            ans_matrix[i] = (int *)malloc(y * sizeof(int));
        }
        //empty the buffer 
        fgets(buffer, BUFFER_SIZE, stdin);
        printf("going with following dimentions : %d,%d,%d\n",x,c,y);
        //printf("connectiong to the server : ...\n");
            
        // Create client socket
        if ((client_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
            perror("socket");
            exit(EXIT_FAILURE);
        }

        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(PORT);

        // Convert IPv4 address from text to binary form
        if (inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr) <= 0) {
            perror("inet_pton");
            exit(EXIT_FAILURE); 
        }

        // Connect to server
        if (connect(client_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
            perror("connect");
            exit(EXIT_FAILURE);
        }

        // sending dimentions
        temp = 3;
        memset(buffer, 0, BUFFER_SIZE);
        sprintf(buffer,"%d %d %d",x,c,y);
        send(client_fd, buffer, strlen(buffer), 0);


        // Communication loop
        printf("\n\n-> please pass the first matrix entries:\n");
        temp = x;
        while (temp > 0) {
            //printf("Enter message: ");
            fgets(buffer, BUFFER_SIZE, stdin);

            send(client_fd, buffer, strlen(buffer), 0);
            memset(buffer, 0, BUFFER_SIZE);
            //recv(client_fd, buffer, BUFFER_SIZE, 0);

            if (buffer[0] == '*') {
                printf("empty input! closing the connection ... \n");
                break;
            }

            //printf("Server recieved: %s", buffer);
            temp-=1;
        }

        printf("\n\n->now pass the second matrix entries:\n");
        temp = c;
        while (temp > 0) {
            printf("Enter message: ");
            fgets(buffer, BUFFER_SIZE, stdin);

            send(client_fd, buffer, strlen(buffer), 0);
            memset(buffer, 0, BUFFER_SIZE);
            //recv(client_fd, buffer, BUFFER_SIZE, 0);

            if (buffer[0] == '*') {
                printf("empty input! closing the connection ... \n");
                break;
            }

            //printf("Server recieved: %s", buffer);
            temp -= 1;
        }
        printf("retrieving the answer:...\n");
        //receiving the ans:
        temp = x*y;
        int i,j,value;
        while(temp > 0){
            memset(buffer, 0, BUFFER_SIZE);
            recv(client_fd, buffer, BUFFER_SIZE, 0);
            printf("-%s\n",buffer);
            sscanf(buffer," %d %d %d",&i,&j,&value);
            ans_matrix[i-1][j-1] = value;
            temp -=1;
        }
        
        printf("your answer is :\n");
        for(int i = 0 ; i < x ; i++){
            for(int j = 0 ; j < y ; j++){
                printf("%d ",ans_matrix[i][j]);
            }
            printf("\n");

        }
        close(client_fd);


    }
    for (int i = 0; i < x; i++) {
        free(ans_matrix[i]);
    }
    free(ans_matrix);
    return 0;



}