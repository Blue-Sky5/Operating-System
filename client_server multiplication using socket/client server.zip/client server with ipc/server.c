// server side 
//importing related libraries:

#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <semaphore.h>
#include <pthread.h>

#define PORT 1191
#define BUFFER_SIZE 1024
// globals --------------------------------------
int thread_count = 3;
int work_amount;
int x,y,c = 0;
int** first_matrix ;
int** second_matrix ;
int** ans_matrix ;
int current_row_g= 1;
int current_col_g = 1;
sem_t load;
pthread_mutex_t mutex_1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t buff_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t read_cond = PTHREAD_COND_INITIALIZER;
int** read_write_buffer; 
int fill_count = 0;
int read_count = 0;
char* ptr;
//.................................................
int server_fd, client_fd, addr_len;
struct sockaddr_in server_addr, client_addr;
char buffer[BUFFER_SIZE];
//.................................................

int calculation(int row , int col){
    int ans = 0;
    for(int i = 0 ; i <c ; i++){
        ans = ans + (first_matrix[row-1][i]* second_matrix[i][col-1]);
    }
    return ans;
}

void * thread_calculation(){
    int current_row;
    int current_col;
    int ans = 0;
    while (1){
        if(sem_trywait(&load) != -1){
            pthread_mutex_lock(&mutex_1);
            current_col = current_col_g;
            current_row = current_row_g;
            if(current_col_g == y){
                current_col_g = 1;
                current_row_g+=1;
            }
            else{
                current_col_g +=1;
            }
            
            pthread_mutex_unlock(&mutex_1);

            ans = calculation(current_row,current_col);
            pthread_mutex_lock(&buff_mutex);
            read_write_buffer[0][fill_count] = current_row;
            read_write_buffer[1][fill_count] = current_col;
            read_write_buffer[2][fill_count] = ans;
            fill_count+=1;
            if(fill_count > read_count){
                pthread_cond_signal(&read_cond);
            }
            pthread_mutex_unlock(&buff_mutex);
            //work_amount -= 1;

        }
        else{
            break;
        }
    }

    pthread_exit(NULL);
    
}

void *read_function(void *arg) {
    while (read_count < x*y){
        pthread_mutex_lock(&buff_mutex);
        while(read_count == fill_count){
            pthread_cond_wait(&read_cond, &buff_mutex);
        }
        memset(buffer, 0, BUFFER_SIZE);
        sprintf(buffer, " %d %d %d", read_write_buffer[0][read_count], read_write_buffer[1][read_count], read_write_buffer[2][read_count]);
        send(client_fd, buffer, strlen(buffer), 0);
        read_count++;
        pthread_mutex_unlock(&buff_mutex);
        memset(buffer, 0, BUFFER_SIZE);

    }
    
}


int main() {
    
    //.......................................
    //int x ,c ,y = 0;
    int temp;
    int input;
    //.......................................
    
    // Create server socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind server socket
    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind");
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_fd, 3) < 0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    addr_len = sizeof(client_addr);
    if ((client_fd = accept(server_fd, (struct sockaddr *)&client_addr, (socklen_t *)&addr_len)) < 0) {
        perror("accept");
        exit(EXIT_FAILURE);
    }

    // Communication loop
    printf("lets see our dimentions.. \n");
    memset(buffer, 0, BUFFER_SIZE);
    ssize_t received = recv(client_fd, buffer, BUFFER_SIZE, 0);
    sscanf(buffer," %d %d %d",&x,&c,&y);
    printf("x: %d c: %d y: %d \n",x,c,y);

    //first matrix ................................................
    first_matrix = (int **)malloc(x * sizeof(int *));
    for(int i = 0 ; i < x ; i++){
        first_matrix[i] = (int *)malloc(c * sizeof(int));
    }

    printf("\n-> getting first matrix :\n");

    for(int i = 0 ; i < x ; i++){
        memset(buffer, 0, BUFFER_SIZE);
        ssize_t received = recv(client_fd, buffer, BUFFER_SIZE, 0);
        ptr = buffer;
        for(int j = 0 ; j < c ; j++){
            sscanf(ptr, "%d", &first_matrix[i][j]);
            //printf("-%d\n",first_matrix[i][j]);
            while (*ptr != ' ' && *ptr != '\0') {
            ptr++;
            }
            if (*ptr == ' ') {
            ptr++;
            }
        }
    }


    //second matrix ................................................
    second_matrix  = (int **)malloc(c * sizeof(int *));
    for(int i = 0 ; i < c ; i++){
        second_matrix[i] = (int *)malloc(y * sizeof(int));
    }

    printf("\n-> getting second matrix :\n");

    for(int i = 0 ; i < c ; i++){
        memset(buffer, 0, BUFFER_SIZE);
        ssize_t received = recv(client_fd, buffer, BUFFER_SIZE, 0);
        ptr = buffer;
        for(int j = 0 ; j < y ; j++){
            sscanf(ptr, "%d", &second_matrix[i][j]);
            //printf("-%d\n",second_matrix[i][j]);
            while (*ptr != ' ' && *ptr != '\0') {
            ptr++;
            }
            if (*ptr == ' ') {
            ptr++;
            }
        }
    }


    //answer matrix ..................................
    ans_matrix = (int **)malloc(x * sizeof(int *));
    for(int i = 0 ; i < x ; i++){
        ans_matrix[i] = (int *)malloc(y * sizeof(int));
    }

    for(int i = 0 ; i < x ; i++){
        for(int j = 0 ; j < y ; j++){
            ans_matrix[i][j] = 0;
        }
    }

    read_write_buffer = malloc(3 * sizeof(int *));
    //read_write_buffer:
    for(int i = 0 ; i < 3 ; i++){
        read_write_buffer[i] =  malloc((x*y) * sizeof(int));
    }
    
    // todo : calculations............................
    pthread_t threads[thread_count];
    work_amount = x*y;
    
    sem_init(&load, 0, 0);
    
    for (int i = 0; i < work_amount; i++) {
        sem_post(&load);
    }

    for (long i = 0; i < thread_count; i++) {
        pthread_create(&threads[i], NULL, thread_calculation, NULL);
    }

    pthread_t reader;
    pthread_create(&reader,NULL,read_function,NULL);
    
    
    
    // Join threads and exit
    for (long i = 0; i < thread_count; i++) {
        pthread_join(threads[i], NULL);
    }
    pthread_join(reader, NULL);

    sem_destroy(&load);
    //...............................................

    printf("Done:)\n");

    for (int i = 0; i < x; i++) {
        free(first_matrix[i]);
    }
    free(first_matrix);

    for (int i = 0; i < c; i++) {
        free(second_matrix[i]);
    }
    free(second_matrix);

    for (int i = 0; i < x; i++) {
        free(ans_matrix[i]);
    }
    for(int i = 0 ; i < 3 ; i++){
        free(read_write_buffer[i]);
    }
    free(ans_matrix);
    free(read_write_buffer);
    close(client_fd);
    close(server_fd);
    return 0;
}
