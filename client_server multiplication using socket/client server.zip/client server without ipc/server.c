#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <semaphore.h>
#include <pthread.h>

#define PORT 1191
#define BUFFER_SIZE 1024
// globals --------------------------------------
int thread_count = 3;
int work_amount;
int x,y,c = 0;
int** first_matrix ;
int** second_matrix ;
int** ans_matrix ;
int current_row_g= 1;
int current_col_g = 1;
sem_t load;
pthread_mutex_t mutex_1 = PTHREAD_MUTEX_INITIALIZER;
//.................................................
struct thread_data{
    int mtx1_r;
    int mtx2_c;
};
//...........................................................
int calculation(int row , int col){
    int ans = 0;
    for(int i = 0 ; i <c ; i++){
        ans = ans + (first_matrix[row-1][i]* second_matrix[i][col-1]);
    }
    return ans;
}

void * thread_calculation(struct thread_data * data){
    int current_row;
    int current_col;
    int ans = 0;
    while (1){
        if(sem_trywait(&load) != -1){
            pthread_mutex_lock(&mutex_1);
            current_col = current_col_g;
            current_row = current_row_g;
            if(current_col_g == y){
                current_col_g = 1;
                current_row_g+=1;
            }
            else{
                current_col_g +=1;
            }
            
            pthread_mutex_unlock(&mutex_1);

            ans = calculation(current_row,current_col);
            pthread_mutex_lock(&mutex_1);
            ans_matrix[current_row - 1 ][current_col -1] = ans;
            pthread_mutex_unlock(&mutex_1);
            //work_amount -= 1;

        }
        else{
            break;
        }
        
    }

    pthread_exit(NULL);
    
}

int main() {
    int server_fd, client_fd, addr_len;
    struct sockaddr_in server_addr, client_addr;
    char buffer[BUFFER_SIZE];
    //.......................................
    //int x ,c ,y = 0;
    int temp;
    int input;
    //.......................................
    
    // Create server socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind server socket
    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind");
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_fd, 3) < 0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    addr_len = sizeof(client_addr);
    if ((client_fd = accept(server_fd, (struct sockaddr *)&client_addr, (socklen_t *)&addr_len)) < 0) {
        perror("accept");
        exit(EXIT_FAILURE);
    }

    // Communication loop
    printf("lets see our dimentions.. \n");
    temp = 3;
    
    while (temp > 0) {
        memset(buffer, 0, BUFFER_SIZE);
        ssize_t received = recv(client_fd, buffer, BUFFER_SIZE, 0);
        if (received <= 0) {
            break;
        }
        if(temp == 3){
            x = atoi(buffer);
            printf("x param: %d", x);
        }
        else if(temp == 2){
            c = atoi(buffer);
            printf("c param: %d", c);
        }
        else{
            y = atoi(buffer);
            printf("y param: %d", y);
        }
        //printf("Client: %s", buffer);
        send(client_fd, buffer, strlen(buffer), 0);
        temp -= 1;
    }

    //first matrix ................................................
    first_matrix = (int **)malloc(x * sizeof(int *));
    for(int i = 0 ; i < x ; i++){
        first_matrix[i] = (int *)malloc(c * sizeof(int));
    }

    printf("\n getting first matrix :\n");

    for(int i = 0 ; i < x ; i++){
        for(int j = 0 ; j < c ; j++){
            memset(buffer, 0, BUFFER_SIZE);
            ssize_t received = recv(client_fd, buffer, BUFFER_SIZE, 0);
            input = atoi(buffer);
            printf("recived %d\n",input);
            send(client_fd, buffer, strlen(buffer), 0);
            first_matrix[i][j] = input;
        }
    }

    //  printf("******\n");
    // for(int i = 0 ; i < x ; i++){
    //     for(int j = 0 ; j < c ; j++){
    //         printf("%d ",first_matrix[i][j]);
    //     }
    //     printf("\n");
    // }
    
    //second matrix ................................................
    second_matrix  = (int **)malloc(c * sizeof(int *));
    for(int i = 0 ; i < c ; i++){
        second_matrix[i] = (int *)malloc(y * sizeof(int));
    }

    printf("\n getting second matrix :\n");

    for(int i = 0 ; i < c ; i++){
        for(int j = 0 ; j < y ; j++){
            memset(buffer, 0, BUFFER_SIZE);
            ssize_t received = recv(client_fd, buffer, BUFFER_SIZE, 0);
            input = atoi(buffer);
            printf("recived %d\n",input);
            send(client_fd, buffer, strlen(buffer), 0);
            second_matrix[i][j] = input;
        }
    }
    // printf("******\n");
    // for(int i = 0 ; i < c ; i++){
    //     for(int j = 0 ; j < y ; j++){
    //         printf("%d ",second_matrix[i][j]);
    //     }
    //     printf("\n");
    // }

    //answer matrix ..................................
    ans_matrix = (int **)malloc(x * sizeof(int *));
    for(int i = 0 ; i < x ; i++){
        ans_matrix[i] = (int *)malloc(y * sizeof(int));
    }

    for(int i = 0 ; i < x ; i++){
        for(int j = 0 ; j < y ; j++){
            ans_matrix[i][j] = 0;
        }
    }
    
    // todo : calculations............................
    struct thread_data data;
    pthread_t threads[thread_count];
    work_amount = x*y;
    
    sem_init(&load, 0, 0);
    
    for (int i = 0; i < work_amount; i++) {
        sem_post(&load);
    }

    for (long i = 0; i < thread_count; i++) {
        pthread_create(&threads[i], NULL, thread_calculation, (void*)i);
    }
    
    
    
    // Join threads and exit
    for (long i = 0; i < thread_count; i++) {
        pthread_join(threads[i], NULL);
    }
    sem_destroy(&load);
    //...............................................

    // printf("********");
    // for(int i = 0 ; i < x ; i++){
    //     for(int j = 0 ; j < y ; j++){
    //         printf("%d ",ans_matrix[i][j]);
    //     }
    //     printf("\n");
    // }

    for(int i = 0 ; i < x ; i++){
        for(int j = 0 ; j < y ; j++){
            memset(buffer, 0, BUFFER_SIZE);
            sprintf(buffer,"%d ", ans_matrix[i][j]);
            send(client_fd, buffer, strlen(buffer), 0);
        }
    }

    printf("Done:)\n");

    for (int i = 0; i < x; i++) {
        free(first_matrix[i]);
    }
    free(first_matrix);

    for (int i = 0; i < c; i++) {
        free(second_matrix[i]);
    }
    free(second_matrix);

    for (int i = 0; i < x; i++) {
        free(ans_matrix[i]);
    }
    free(ans_matrix);

    close(client_fd);
    close(server_fd);
    return 0;
}