// client side 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>


#define PORT 1191
#define BUFFER_SIZE 1024
#define SERVER_IP "127.0.0.1"

int main() {
    int client_fd;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];
    int x , y ,c = 0;
    int temp = 0;
    //..................................................

    //..................................................
    printf("For your multiplication please provide three numbers reguarding your input matracies dimentions:\n");
    scanf("%d %d %d",&x , &c, &y);
    //empty the buffer 
    fgets(buffer, BUFFER_SIZE, stdin);
    printf("going with following dimentions : %d,%d,%d\n",x,c,y);
    printf("connectiong to the server : ...\n");


    // Create client socket
    if ((client_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);

    // Convert IPv4 address from text to binary form
    if (inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr) <= 0) {
        perror("inet_pton");
        exit(EXIT_FAILURE); 
    }

    // Connect to server
    if (connect(client_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("connect");
        exit(EXIT_FAILURE);
    }

    temp = 3;
    while (temp > 0) {
        //printf("Enter message: ");
        //fgets(buffer, BUFFER_SIZE, stdin);
        if(temp == 3){
            sprintf(buffer, "%d", x);
        }
        else if(temp == 2){
            sprintf(buffer, "%d", c);
        }
        else{
            sprintf(buffer, "%d", y);
        }

        send(client_fd, buffer, strlen(buffer), 0);
        memset(buffer, 0, BUFFER_SIZE);
        recv(client_fd, buffer, BUFFER_SIZE, 0);

        if (buffer[0] == '*') {
            printf("closing the connection ... \n");
            break;
        }

        printf("Server recieved: %s", buffer);
        temp-=1;
    }

    // Communication loop
    printf("\n\n please pass the first matrix entries:\n");
    temp = x*c;
    while (temp > 0) {
        //printf("Enter message: ");
        fgets(buffer, BUFFER_SIZE, stdin);

        send(client_fd, buffer, strlen(buffer), 0);
        memset(buffer, 0, BUFFER_SIZE);
        recv(client_fd, buffer, BUFFER_SIZE, 0);

        if (buffer[0] == '*') {
            printf("closing the connection ... \n");
            break;
        }

        printf("Server recieved: %s", buffer);
        temp-=1;
    }

    printf("\n\n now pass the second matrix entries:\n");
    temp = c*y;
    while (temp > 0) {
        printf("Enter message: ");
        fgets(buffer, BUFFER_SIZE, stdin);

        send(client_fd, buffer, strlen(buffer), 0);
        memset(buffer, 0, BUFFER_SIZE);
        recv(client_fd, buffer, BUFFER_SIZE, 0);

        if (buffer[0] == '*') {
            printf("closing the connection ... \n");
            break;
        }

        printf("Server recieved: %s", buffer);
        temp -= 1;
    }

    printf("looks fine so far!, waiting for server to respond!\n");
    for(int i = 0 ; i < x ; i++){
        for(int j = 0 ; j < y ; j++){
            memset(buffer, 0, BUFFER_SIZE);
            recv(client_fd, buffer, BUFFER_SIZE, 0);
            printf("%s ", buffer);
        }
        printf("\n");
        

    }

    printf("\n Done :)\n");

    close(client_fd);
    return 0;
}